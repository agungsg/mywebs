# Google Spreadsheet

> Memanfaatkan Google Spreadsheet dan Google Scripts sebagai backend (API).

Tutorial konfigurasi sedang dikerjakan.