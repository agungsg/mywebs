module.exports = {
    school: {
        name: "SMK Negeri 1 Pemalang",
        address: "Jl. Gatot Subroto No. 31, Bojongbata, Kec. Pemalang, Kabupaten Pemalang, Jawa Tengah 52319",
        website: "https://smkn1pml.sch.id/",
        logo: "https://smkn1pml.sch.id/assets/images/logo.png",
        contact: {
            email: "email@smk.sch.id",
            phone: "028xxxxxxx",
            whatsapp: "628xxxxxxxxxx"
        },
        socials: {
            facebook: "smkn1pemalang",
            instagram: "smkn1pml",
            twitter: "smkn1pemalang"
        }
    },
    database: "https://script.google.com/macros/s/AKfycbw6dZn8tLl64FruZbz7b9NMMm5yketRkLFsSdjNduP7P6JqRJ7KHvaewBkSRpT8w61skQ/exec"
}