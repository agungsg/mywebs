module.exports = {
    hot: true,
    contentBase: 'assets',
    publicPath: 'build',
    historyApiFallback: '__app.html',
    port: 5000
}