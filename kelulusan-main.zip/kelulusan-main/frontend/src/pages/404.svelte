<script>
    import Fallback from "./_fallback.svelte";
</script>

<Fallback />
